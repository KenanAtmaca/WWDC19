import Foundation
import SpriteKit

public class Node {
    public static func titleNode(title:String,font:String, size:CGFloat, position: CGPoint, color: UIColor, name:String) -> SKLabelNode {
        let titleNode = SKLabelNode(fontNamed: font)
        titleNode.numberOfLines = 2
        titleNode.name = name
        titleNode.text = title
        titleNode.fontSize = size
        titleNode.fontColor = color
        titleNode.position = position
        return titleNode
    }
    
    public static func spriteNode(imageName:String, scale:CGFloat, position: CGPoint) -> SKSpriteNode {
        let logoNode = SKSpriteNode(imageNamed: imageName)
        logoNode.setScale(scale)
        logoNode.position = position
        return logoNode
    }
    
    public static func emitterNode(name:String, position:CGPoint) -> SKEmitterNode {
        if let particle = SKEmitterNode(fileNamed: name) {
            particle.position = position
            particle.name = name
            particle.zPosition = 0
            return particle
        }
        return SKEmitterNode()
    }
    
    public static func audioNode(name:String) -> SKAudioNode {
        if let musicURL = Bundle.main.url(forResource: name, withExtension: "aiff") {
            return SKAudioNode(url: musicURL)
        }
        return SKAudioNode()
    }
    
    public static func shapeNode(rect: CGRect, color: UIColor) -> SKShapeNode {
        let shapeNod = SKShapeNode(rect: rect)
        shapeNod.fillColor = color
        shapeNod.strokeColor = color
        return shapeNod
    }
}

