import Foundation
import SpriteKit

public class Action {
    public static func opacity(alpha: CGFloat, duration: TimeInterval) -> SKAction {
       let opacityActionBy = SKAction.fadeAlpha(by: 1, duration: duration)
       let opacityActionTo = SKAction.fadeAlpha(to: alpha, duration: duration)
       let sequence = SKAction.sequence([opacityActionBy, opacityActionTo])
       return SKAction.repeatForever(sequence)
    }
    
    public static func scale(value: CGFloat) -> SKAction {
        let scaleActionBy = SKAction.scale(by: 0.8, duration: 0.5)
        let scaleActionTo = SKAction.scale(to: value, duration: 0.5)
        let sequence = SKAction.sequence([scaleActionBy, scaleActionTo])
        return SKAction.repeatForever(sequence)
    }
    
    public static func playSound(name: String) -> SKAction {
        return SKAction.playSoundFileNamed(name, waitForCompletion: false)
    }
    
    public static func runBlock(block: @escaping (() -> Void), wait: TimeInterval, repeatAction: Bool) -> SKAction {
        var finalAction = SKAction()
        let blockAction = SKAction.run(block)
        let waitAction = SKAction.wait(forDuration: wait)
        if repeatAction {
            finalAction = SKAction.repeatForever(SKAction.sequence([waitAction, blockAction, SKAction.removeFromParent()]))
        } else {
            finalAction = SKAction.sequence([waitAction, blockAction])
        }
        return finalAction
    }
}
