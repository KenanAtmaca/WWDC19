import UIKit
import SpriteKit

open class GameScene: SKScene {
    
    struct Bits {
        static let iphone:UInt32 = 1
        static let version:UInt32 = 2
        static let ground:UInt32 = 3
    }
    
    var versionNode:SKLabelNode!
    var iphoneNode:SKSpriteNode!
    var groundNode:SKShapeNode!
    var backgroundAudio:SKAudioNode!
    var versionNodes:[SKSpriteNode] = []
    
    var version:Float = 1.0
    var latestVersion:Float = 13.0
    var isSound:Bool = true
    var gravity:CGFloat = -4
    
    open override func didMove(to view: SKView) {
        setupUI()
        setupPopView(titleText: "Upgrade Version 📲", background: .white, fontColor: .black)
        if isSound { backgroundAudio = Node.audioNode(name: "wiin") }
    }
    
    func setupUI() {
        self.backgroundColor = .white
        for i in 1..<6 {
            let serverNode = Node.spriteNode(imageName: "server", scale: 0.4, position: CGPoint(x: 100.0 * CGFloat(i), y: self.frame.height - 60))
            addChild(serverNode)
        }
        versionNode = Node.titleNode(title: "iOS \(version)", font: "Avenir", size: 70, position: CGPoint(x: self.frame.width / 2, y: self.frame.height / 2 - 50), color: UIColor.color(hex: "#E7E7E7"), name: "VersionLabel")
        iphoneNode = Node.spriteNode(imageName: "iphone", scale: 1, position: CGPoint(x: self.frame.width / 2, y: 50))
        iphoneNode.name = "iphone"
        groundNode = Node.shapeNode(rect: CGRect(x: 0, y: 0, width: self.frame.width, height: 2), color: .clear)
        groundNode.name = "ground"
        addChild(iphoneNode)
        addChild(groundNode)
        addChild(versionNode)
    }
    
    func setupPopView(titleText: String, background: UIColor, fontColor: UIColor) {
        let blackScreen = SKShapeNode(rectOf: self.frame.size)
        blackScreen.name = "popView"
        blackScreen.fillColor = background.withAlphaComponent(0.7)
        blackScreen.strokeColor = background.withAlphaComponent(0.7)
        blackScreen.position = CGPoint(x: self.frame.width / 2, y: self.frame.height / 2)
        addChild(blackScreen)
        
        let title = SKLabelNode()
        title.text = titleText
        title.fontName = "Avenir"
        title.fontSize = 31
        title.fontColor = fontColor
        title.position = CGPoint(x: 0, y: 100)
        blackScreen.addChild(title)
        
        let playButton = SKSpriteNode(imageNamed: "play")
        playButton.position = CGPoint(x: 0, y: 0)
        playButton.run(Action.scale(value: 1.3))
        playButton.name = "play"
        playButton.zPosition = 1
        blackScreen.addChild(playButton)
    }
    
    func spawnVersionNodes() {
        let nodesName = ["apple","android"]
        let randomNodeName = nodesName[Int.random(in: 0...1)]
        let nodePosition = CGPoint(x: CGFloat.random(in: 50...500), y: self.frame.height - 150)
        let versionNode = Node.spriteNode(imageName: randomNodeName, scale: 0.8, position: nodePosition)
        versionNode.name = randomNodeName
        versionNode.physicsBody = SKPhysicsBody(circleOfRadius: versionNode.frame.width / 2)
        versionNode.physicsBody?.affectedByGravity = true
        versionNode.physicsBody?.isDynamic = true
        versionNode.physicsBody?.allowsRotation = true
        versionNode.physicsBody?.categoryBitMask = Bits.version
        versionNode.physicsBody?.contactTestBitMask = Bits.iphone | Bits.ground
        addChild(versionNode)
        versionNodes.append(versionNode)
    }
    
    func startActions() {
        let startAction = Action.runBlock(block: {
            self.spawnVersionNodes()
        }, wait: 1, repeatAction: true)
        self.run(startAction)
    }
    
    func setupPhysics() {
        self.physicsWorld.gravity = CGVector(dx: 0, dy: gravity)
        self.physicsWorld.contactDelegate = self
        iphoneNode.physicsBody = SKPhysicsBody(circleOfRadius: iphoneNode.frame.width / 3)
        iphoneNode.physicsBody?.isDynamic = false
        iphoneNode.physicsBody?.affectedByGravity = false
        iphoneNode.physicsBody?.categoryBitMask = Bits.iphone
        iphoneNode.physicsBody?.contactTestBitMask = Bits.version
        
        groundNode.physicsBody = SKPhysicsBody(edgeFrom: CGPoint(x: 0, y: 0), to: CGPoint(x: self.frame.width, y: 0))
        groundNode.physicsBody?.affectedByGravity = false
        groundNode.physicsBody?.isDynamic = false
        groundNode.physicsBody?.categoryBitMask = Bits.ground
        groundNode.physicsBody?.contactTestBitMask = Bits.version
    }
    
    open override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first!
        let location = touch.location(in: self)
        guard let nodeName = atPoint(location).name else { return }
        if nodeName == "play" {
            versionNodes.removeAll()
            version = 1.0
            versionNode.text = "iOS \(String(format: "%.1f", arguments: [version]))"
            iphoneNode.position.x = self.frame.width / 2
            backgroundAudio.removeFromParent()
            if let emitterNode = childNode(withName: "Confetti") { emitterNode.removeFromParent() }
            let popView = childNode(withName: "popView")!
            popView.removeFromParent()
            setupPhysics()
            let waitAction = Action.runBlock(block: {
                self.startActions()
            }, wait: 0, repeatAction: false)
            self.run(waitAction)
        }
    }
    
    open override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            guard let nodeName = atPoint(location).name else { return }
            if nodeName == "iphone" {
                if location.x >= 50.0 && location.x <= 550 {
                   iphoneNode.position.x = location.x
                }
            }
        }
    }
}

extension GameScene: SKPhysicsContactDelegate {
    public func didBegin(_ contact: SKPhysicsContact) {
        var firstBody = contact.bodyA
        var secondBody = contact.bodyB
        
        if (firstBody.node?.physicsBody?.categoryBitMask)! < (secondBody.node?.physicsBody?.categoryBitMask)! {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        } else {
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        
        if firstBody.categoryBitMask == Bits.iphone && secondBody.categoryBitMask == Bits.version {
            if secondBody.node!.name == "android" {
                self.removeAllActions()
                self.versionNodes.forEach { (node) in node.removeFromParent() }
                setupPopView(titleText: "iOS \(String(format: "%.1f", arguments: [version])) is older version ☹️", background: UIColor.black, fontColor: .white)
                if isSound { self.run(Action.playSound(name: "gameover")) }
            } else {
                secondBody.node!.removeFromParent()
                version += 0.1
                versionNode.text = "iOS \(String(format: "%.1f", arguments: [version]))"
                if latestVersion <= version {
                    self.removeAllActions()
                    self.versionNodes.forEach { (node) in node.removeFromParent() }
                    setupPopView(titleText: "iOS \(String(format: "%.1f", arguments: [version])) uploaded 🎉", background: UIColor.black, fontColor: .white)
                    if isSound { addChild(backgroundAudio) }
                    self.addChild(Node.emitterNode(name: "Confetti", position: CGPoint(x: self.frame.width / 2 + 100, y: self.frame.height)))
                } else {
                    if isSound { self.run(Action.playSound(name: "upgrade")) }
                }
            }
        }
        
        if firstBody.categoryBitMask == Bits.version && secondBody.categoryBitMask == Bits.ground {
            if firstBody.node!.name == "apple" {
                self.removeAllActions()
                self.versionNodes.forEach { (node) in node.removeFromParent() }
                setupPopView(titleText: "iOS \(String(format: "%.1f", arguments: [version])) is older version ☹️", background: UIColor.black, fontColor: .white)
                if isSound { self.run(Action.playSound(name: "gameover")) }
            } else {
                firstBody.node!.removeFromParent()
            }
        }
    }
}
