import UIKit
import SpriteKit
import AVFoundation

open class GameVC: UIViewController {
    
    var gameView:SKView!
    var scene:GameScene!
    
    open func setupScene() {
        let screenSize = CGRect(x: 0, y: 0, width: 600, height: 600)
        self.preferredContentSize = screenSize.size
        gameView = SKView(frame: screenSize)
        scene = GameScene(size: screenSize.size)
        gameView.presentScene(scene)
        self.view.addSubview(gameView)
    }
    
    open func changeLatestVersion(version: Float) {
        scene.latestVersion = abs(version)
    }
    
    open func changeSoundState(state: Bool) {
        scene.isSound = state
    }
    
    open func changeGravity(gravity: CGFloat) {
        scene.gravity = gravity
    }
    
    open func changeBackgroundColor(color: UIColor) {
        scene.backgroundColor = color
    }
}

