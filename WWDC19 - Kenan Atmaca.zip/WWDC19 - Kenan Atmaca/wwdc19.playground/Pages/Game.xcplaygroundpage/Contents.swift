import UIKit
import PlaygroundSupport

//: [Previous page](@previous)
/*:
 * Experiment:
 Let's start our fun game with the .setupScene() function.
 
 - Note:
 You can change the game flow with the following auxiliary functions.
 */
 let scene = GameVC()
 scene.setupScene()
/*:
 ### iOS Version 📲
 By default, when you reach iOS 13, you have successfully completed the game. But you can change this latest version.
 */
 scene.changeLatestVersion(version: 13.0)
/*:
 ### Gravity 🌍
 You can change the gravity within the game stream and make the game easier or more difficult.
 - Note:
 The gravity should be set to (-y)
 */
 scene.changeGravity(gravity: -4)
/*:
 ### Background Color 🎨
 You can easily change the background color of the game.
 */
 let bgColor:UIColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
 scene.changeBackgroundColor(color: bgColor)
/*:
 ### Sound 🔊
 You can easily turn off the sounds in the game.
 */
 scene.changeSoundState(state: true)

 PlaygroundPage.current.liveView = scene

