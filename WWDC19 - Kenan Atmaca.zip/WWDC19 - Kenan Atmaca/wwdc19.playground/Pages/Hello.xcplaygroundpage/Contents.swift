import Foundation

/*:
 ### Overview
 #### Update Version - WWDC 19 Submission 🎉
 ##### * Kenan Atmaca 👨🏻‍💻
 
 The game was designed in 2D and was prepared in a pleasant way 😘 The purpose of the game is hooking iOS versions which are came from servers, and reaching the latest version iOS 13. You can upgrade new iOS versions by escaping from Android versions. The game will end if your iPhone touch to Android versions or the iOS versions are missed.
 
 
 - Note:
 **By changing the game's functional points in the playground, you can steer the game to make make it difficult. By this way you will have an interactive gaming experience with Swift Playground.**
 
 
 I hope you have fun ❤️
 
 [Next page](@next)
 */
